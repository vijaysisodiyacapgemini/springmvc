package com.cg.carrentalspringboot.dto;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Entity
public class Driver {

	private String name;
	@Id
	private Long mobNumber;
	private String LicenceNumber;

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getMobNumber() {
		return mobNumber;
	}
	public void setMobNumber(Long mobNumber) {
		this.mobNumber = mobNumber;
	}
	
	public String getLicenceNumber() {
		return LicenceNumber;
	}
	public void setLicenceNumber(String licenceNumber) {
		LicenceNumber = licenceNumber;
	}
	@Override
	public String toString() {
		return "Driver   Name : " + name + " MobNumber:"  + mobNumber + " LicenceNumber:"  + LicenceNumber + " \n ";
	}

}
