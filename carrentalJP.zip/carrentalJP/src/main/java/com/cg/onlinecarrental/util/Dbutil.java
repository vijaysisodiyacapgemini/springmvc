package com.cg.onlinecarrental.util;
import com.cg.onlinecarjdbc.dto.*;
import com.cg.onlinecarrental.exception.CarException;
import javax.persistence.*;

 
public class Dbutil {
	 
	public static EntityManager em=null;
	 
	public static EntityManager getConnection()
	{
		 
			EntityManagerFactory emf=Persistence.createEntityManagerFactory("demofive");
			EntityManager em=emf.createEntityManager();
			
			return em;
		 
	
	}
}