package com.cg.onlinecarjdbc.service;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
 
 
import com.cg.onlinecarrental.exception.CarException;
import com.cg.onlinecarjdbc.dao.CarDaoImpl;
import com.cg.onlinecarjdbc.dto.Car;
 
public class CarServiceImpl implements CarService{
     CarDaoImpl cardaoimpl;
     public float totalamount;
     public CarServiceImpl() {
		 cardaoimpl=new CarDaoImpl();
		// TODO Auto-generated constructor stub
	}
	public Car bookCar(Car car) throws CarException {
		
		try{
			// TODO Auto-generated method stub
			return cardaoimpl.save(car);
		}
	 catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		return car;
	}
	public Car showBookingDetail(String carno) throws CarException {
	   Car obj= cardaoimpl.findCarByNo(carno);
	   
	   Date d1=obj.getBookingdetail().getPickupDate();
	   Date d2=obj.getBookingdetail().getDropDate();
	  
	  

	    

	    // Get msec from each, and subtract.
	    long diff = d2.getTime() - d1.getTime();
	    
	    long diffMinutes = diff / (60 * 1000) % 60;
	    long diffHours = diff / (60 * 60 * 1000);
	     
	    totalamount=(obj.getRateHour()*diffHours)+(obj.getRateHour()/60*diffMinutes);
	   return obj;
	}
   public List<Car> viewAvailableCars() throws CarException
   {
	   return cardaoimpl.geCars();
   }
  public boolean cancelBooking(String carno) throws CarException
  {  
 
	  boolean bool=cardaoimpl.delete(carno);
	   
	return  bool;
} 
     

  }
