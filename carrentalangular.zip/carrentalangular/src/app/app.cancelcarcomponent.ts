
import { Component, OnInit } from "@angular/core";

import { CarService } from "./app.carservice";

@Component({
    selector:'car-app',
    templateUrl:'cancelbooking.html'
})
export class CancelCarcomponent implements OnInit
{

   constructor(private carservie:CarService){ }
  model:string;

   ngOnInit()
   {
     
   }
   cancel()
   {
    this.carservie.cancel(this.model).subscribe((data) =>console.log(data)); 
    
   }
  
}