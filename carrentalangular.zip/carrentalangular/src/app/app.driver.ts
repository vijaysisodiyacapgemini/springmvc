

export class Driver
{
    name:string;
    mobnumber:number;
    licence:string;

    
    
}