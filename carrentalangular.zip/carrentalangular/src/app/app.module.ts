﻿import { NgModule, CUSTOM_ELEMENTS_SCHEMA }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import {CarComponent}  from'./app.carcomponent';
import {HttpClientModule}   from '@angular/common/http';
import{Routes,RouterModule} from '@angular/router';
import{FormsModule} from '@angular/forms';
import { BookingComponent } from './app.bookingcomponent';

import { showBookingDetail } from './app.showbookingcomponet';
import { CancelCarcomponent } from './app.cancelcarcomponent';
import { Drivercomponent } from './app.drivercomponent';

const route:Routes=[
    {path:"addcar",component:Drivercomponent},
    
    {path:"search",component:showBookingDetail},
    {path:"showall",component:BookingComponent},
    {path:"cancel",component:CancelCarcomponent},
];



@NgModule({
    imports: [
        BrowserModule,HttpClientModule,RouterModule.forRoot(route),FormsModule
        
    ],
    declarations: [
        AppComponent,showBookingDetail,BookingComponent,CancelCarcomponent,Drivercomponent
		],
    providers: [ ],
    bootstrap: [AppComponent],
    schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})

export class AppModule { }