package com.cg.onlinecarrental.util;
import java.util.*;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.stereotype.Component;

import com.cg.onlinecarrental.dto.Car;

public class Dbutil {
	public static  Map<String ,Car> listcar;
	  static {
		 listcar =new HashMap<String ,Car>();
		
		 }
		 
	 }
