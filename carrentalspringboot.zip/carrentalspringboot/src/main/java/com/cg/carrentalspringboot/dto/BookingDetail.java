package com.cg.carrentalspringboot.dto;
import java.math.BigDecimal;
import java.util.*;

import javax.annotation.Resource;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Entity
public class BookingDetail {
	@Id
	private int id;
	private String pickupPoint;
	private String dropPoint;
	@Temporal(TemporalType.TIMESTAMP)
	private Date pickupDate;
	@Temporal(TemporalType.TIMESTAMP)
	private Date dropDate;
	private BigDecimal totalamount;
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="booking_id")
	private List<Driver> drivers=new ArrayList<Driver>();
	 
	public BigDecimal getTotalamount() {
		return totalamount;
	}

	public void setTotalamount(BigDecimal totalamount) {
		this.totalamount = totalamount;
	}

	public int getId() {
		return id;
	}
	
	public  int getPId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPickupPoint() {
		return pickupPoint;
	}

	public void setPickupPoint(String pickupPoint) {
		this.pickupPoint = pickupPoint;
	}

	public String getDropPoint() {
		return dropPoint;
	}

	public void setDropPoint(String dropPoint) {
		this.dropPoint = dropPoint;
	}

	public Date getPickupDate() {
		return pickupDate;
	}

	public void setPickupDate(Date pickupDate) {
		this.pickupDate = pickupDate;
	}

	public Date getDropDate() {
		return dropDate;
	}

	public void setDropDate(Date dropDate) {
		this.dropDate = dropDate;
	}

	public List<Driver> getDrivers() {
		return drivers;
	}

	public void setDrivers(List<Driver> drivers) {
		this.drivers = drivers;
	}
	@Override
	public String toString() {
		return "\n PickupPoint: " + pickupPoint + " DropPoint:" + dropPoint + ",\n PickupDate : " + pickupDate
				+ " DropDate:" + dropDate + "  \n TOTAL AMOUNT  " + totalamount +"\n "
				+ drivers;
	}

}
