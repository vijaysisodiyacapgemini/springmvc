package com.cg.carrentalspringboot.controller;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.carrentalspringboot.dto.BookingDetail;
import com.cg.carrentalspringboot.dto.Car;
import com.cg.carrentalspringboot.dto.Driver;
import com.cg.carrentalspringboot.exception.CarException;
import com.cg.carrentalspringboot.service.CarService;


@RestController
@RequestMapping("/car")
public class CarController {
	
	
	
	@Autowired
	CarService service;
	List<Driver> mylist=new ArrayList<Driver>();
	Car carobj;
	
	
	
   @RequestMapping(value="/showall",method=RequestMethod.GET)
   public ResponseEntity<List<Car>> showall()
   {
	   List<Car> mylist;
	  try {
		   mylist = service.viewAvailableCars();
		   return  new ResponseEntity<List<Car>>(mylist,HttpStatus.OK);
		   
	  }
	   catch (CarException e) {
		// TODO Auto-generated catch block
		   return new ResponseEntity("No Car To Show",HttpStatus.NOT_FOUND);
	      }
     }
   
   //************************************method ends *****************************************
   
   
	
	@RequestMapping(value="/showbookingdetail",method=RequestMethod.POST)
	 public ResponseEntity<Car> showBookingDetail(@RequestParam("carno") String carno)
	{
		 
		try {
			Car car=service.showBookingDetail(carno);
			 return new ResponseEntity(car,HttpStatus.NOT_FOUND);
		} catch (CarException e) {
			// TODO Auto-generated catch block
			 return new ResponseEntity("No Booking Detail Found , Please Enter another Car Number",HttpStatus.NOT_FOUND);
		}
		
	}
	
	//*********************************method ends *******************************************
	
	
	@RequestMapping(value="/addall",method=RequestMethod.POST)
    public ResponseEntity<String> addCar(@ModelAttribute Car car ,
    		     @ModelAttribute BookingDetail bookingdetail,
    		      @RequestParam("pickupDAte") String pdate,
    		      @RequestParam("dropDAte")String ddate)
    		
       {
		
		
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/mm/yy hh:mm");
		Date pickupDate = null;
		Date dropDate=null;
		try {
			pickupDate = dateFormat.parse(pdate);
		    dropDate=dateFormat.parse(ddate);
		    bookingdetail.setPickupDate(pickupDate);
		    bookingdetail.setDropDate(dropDate);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			 return new ResponseEntity<String>("enter date and time only  dd/mm/yy hh:mm",HttpStatus.NOT_FOUND);
		}
		
		
		
		
		
		
		
		
		
		  try
		  {
		  service.showBookingDetail(car.getCarno());
		  return new ResponseEntity<String>("This Car is already Booked , please Enter another Car Number",HttpStatus.NOT_FOUND);
		  
		  }
		  catch(CarException e){
		
		  long diff = bookingdetail.getDropDate().getTime() - bookingdetail.getPickupDate().getTime();  // calculating the amount of booking 
		  long diffMinutes = diff / (60 * 1000) % 60;
		  long diffHours = diff / (60 * 60 * 1000);
	     BigDecimal totalamount=BigDecimal.valueOf((car.getRateHour()*diffHours)+(car.getRateHour()/60*diffMinutes));
	     bookingdetail.setTotalamount(totalamount);
		 
	     try {
	    	 car.setBookingdetail(bookingdetail);
			 service.bookCar(car);
			return new ResponseEntity<String>("You have submitted the data",HttpStatus.OK);
		} catch (CarException e1) {
			// TODO Auto-generated catch block
			return new ResponseEntity<String>("Data is not Submitted",HttpStatus.NOT_FOUND);
		}
		  }
    }
	     
	//     this.carobj=car;
		 
		 
		 
	    // return new ResponseEntity<Car>(carobj,HttpStatus.OK); 
	     
	     
	
	//********************************method ends ***************************************	
		 
		 
    
	
	
	//**********************************method ends*******************************
	
	
	
	
	//*******************************end method ********************************************
	
	
	@RequestMapping(value="/cancel",method=RequestMethod.POST)
    public ResponseEntity<String> delete(@RequestParam("carno") String carno)
    		
    {
		   try {
			service.cancelBooking(carno);
			return new ResponseEntity<String>("Your BookingDetail Has Been Canceled .",HttpStatus.OK);
	         } 
		    
		   catch (CarException e1) {
			// TODO Auto-generated catch block
			return new ResponseEntity<String>("Data Not submitted",HttpStatus.NOT_FOUND);
		    }
		
	}

  
}
//**************************************end of the program ******************************************