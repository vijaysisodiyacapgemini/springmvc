package com.cg.carrentalspringboot.exception;

public class CarException extends Exception{
	
	
	public CarException(){
		super();}
    public CarException(String msg) {
    	super(msg);
    }

}
