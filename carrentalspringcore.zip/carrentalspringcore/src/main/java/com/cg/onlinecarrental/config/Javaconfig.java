package com.cg.onlinecarrental.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.cg.onlinecarrental.*")
public class Javaconfig {

}
