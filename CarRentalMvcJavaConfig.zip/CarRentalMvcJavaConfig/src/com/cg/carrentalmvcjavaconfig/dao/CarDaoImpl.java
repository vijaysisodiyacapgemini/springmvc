package com.cg.carrentalmvcjavaconfig.dao;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;





import java.util.*;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.carrentalmvcjavaconfig.dto.Car;
import com.cg.carrentalmvcjavaconfig.exception.CarException;


 
@Repository
public class CarDaoImpl implements CarDao {

	
	@PersistenceContext
	 EntityManager em;
	
	@Override
	public Car save(Car car)  {
		// TODO Auto-generated method stub
	
		em.persist(car);
		em.flush();
		return car;
	}
	
	/* 
	  *above method is Booking the  cars 
	  */

	@Override
	public Car findCarByNo(String carno) {
		// TODO Auto-generated method stub
		return em.find(Car.class, carno);
		
	}
	
	/* 
	  *above method is getting the booking detail of  the cars 
	  */

	@Override
	public List<Car> geCars() {
		// TODO Auto-generated method stub
		Query query=em.createQuery("select c from Car c");
		List<Car> mylist=query.getResultList();
		System.out.println(mylist);
		return mylist;
	}
	
	
	/* 
	  *above method is getting all the Booked cars 
	  */

	@Override
	public boolean delete(String carno)  {
		// TODO Auto-generated method stub
		Car obj=em.find(Car.class, carno);
		if(obj==null)
		{
		  return false;	
		}
		else
		{
		 em.remove(obj);
		 return true;
		}
	}

	/* 
	 * this method is deleting the booking car detail
	 */
	 
	   
	 
	}
