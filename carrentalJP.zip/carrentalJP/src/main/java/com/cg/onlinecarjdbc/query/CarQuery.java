package com.cg.onlinecarjdbc.query;

public interface CarQuery {
	public static final String queryone="select * from bookingdetail where carno=?";
	public static final String query="insert into bookingdetail(pickuppoint,droppoint,pickupDate,dropDate,carno) values(?,?,?,?,?)";
	public static final String query2="select id from bookingdetail where carno=?";
	public static final String query1="insert into Driver values(?,?,?,?)";
	public static final String query3="select * from driver where id=?";
	public static final String query4="select * from car where carno=?";
	public static final String fetchcar="select * from car";
	public static final  String deletequery=" delete from bookingDetail where carno=?";
}
