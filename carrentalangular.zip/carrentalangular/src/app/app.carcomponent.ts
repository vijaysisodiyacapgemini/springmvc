import {Component,OnInit} from'@angular/core';

import { Car } from './app.Car';
import { Router} from '@angular/router';
import { CarService } from './app.carservice';


@Component({
    selector:'car-app',
    templateUrl:'app.car.html'
   
    
})
export class CarComponent implements OnInit
{

    
  
      
    //counter:number=5;

    //carobj:Car;
    constructor(private router:Router,private carservice:CarService){
        
        
     }
   
     model:any={};
    ngOnInit()
    {
        //this.carservice.showBookingDetail().subscribe((data:Car)=>this.carobj=data);
    }
    addcar()
    {
        
        //this.carservice.addCar(this.model).subscribe((data:Car)=>console.log(data));
        

        
     //this.carservice.addCar(this.car).subscribe((data)=>console.log(data));
    }
  
    
 }