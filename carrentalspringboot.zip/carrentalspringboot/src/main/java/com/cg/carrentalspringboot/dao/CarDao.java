package com.cg.carrentalspringboot.dao;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.cg.carrentalspringboot.dto.Car;



@EnableJpaRepositories
public interface CarDao extends JpaRepository<Car, Integer>{

	Car findBycarno(String carno);
	

}
