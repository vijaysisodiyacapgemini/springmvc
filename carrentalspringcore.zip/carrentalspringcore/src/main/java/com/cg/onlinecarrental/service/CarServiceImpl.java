package com.cg.onlinecarrental.service;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.onlinecarrental.dao.CarDaoImpl;
import com.cg.onlinecarrental.dto.Car;
import com.cg.onlinecarrental.exception.CarException;


@Service("carservice") 
public class CarServiceImpl implements CarService{
	/* here we are going to aotowire
	 * */
	 
	 @Autowired
     CarDaoImpl cardaoimpl;
	 /*
     this method is is saving
     the booking detail of the car
   */
	 
    public Car bookCar(Car car) throws CarException {
	 
			  
			 Car carobj=cardaoimpl.save(car);    
			if(car==null)
			{
				throw new CarException("you are not booking the car");
			}
			else
			{
				return carobj;
			}
			
		
	
	}
    /*
       this method is is getting 
       the booking detail of the car
     */
	public Car showBookingDetail(String carno) throws CarException {
		 Car obj= cardaoimpl.findCarByNo(carno);
		   if(obj==null)
				throw new CarException("please Enter your Correct Booking  car Number");
			else
			{
	
	   return obj;
			}
	}
   public List<Car> viewAvailableCars() throws CarException
   {
	   if(cardaoimpl.geCars()==null)
	   {
		   throw new CarException(" No One has booked the car");
	   }
	   else
	   {
		   return cardaoimpl.geCars();
	   }
   }
   
   /*
   this method is is canceling 
   the booking detail of the car
 */
   
  public boolean cancelBooking(String carno) throws CarException
  {  
 

	  boolean bool=cardaoimpl.delete(carno);
	  if(bool)
	  {
		  return true;
	  }
	  else
	  {
		  throw new CarException("please enter valid car Number");
	  }
} 
     

  }
