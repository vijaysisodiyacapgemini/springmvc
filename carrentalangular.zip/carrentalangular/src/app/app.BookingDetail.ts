import { Driver } from "./app.driver";


export class BookingDetail{
    id:number;
    pickupPoint:string;
    dropPoint:string;
    pickupDate:string;
    dropDate:string;
    totalamount:number;
    driver:Driver[];


}