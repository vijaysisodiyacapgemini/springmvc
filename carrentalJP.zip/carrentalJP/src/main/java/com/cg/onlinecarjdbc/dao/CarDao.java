package com.cg.onlinecarjdbc.dao;
import java.util.List;

import com.cg.onlinecarjdbc.dto.Car;
import com.cg.onlinecarrental.exception.CarException;
public interface CarDao {
	public Car save(Car car) throws CarException;
	public Car findCarByNo(String carno) throws CarException;
	public List<Car> geCars() throws CarException;
	public boolean delete(String carno) throws CarException;
	 

}
