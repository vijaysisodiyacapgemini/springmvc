package com.cg.onlinecarrental.dao;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;





import java.util.*;
import java.util.Date;

import org.springframework.stereotype.Repository;

import com.cg.onlinecarrental.dto.Car;
import com.cg.onlinecarrental.exception.CarException;
import com.cg.onlinecarrental.util.Dbutil;
 
@Repository
public class CarDaoImpl implements CarDao {

	
	  /*
    this method is is saving 
    the booking detail of the car into the Map collection
  */
	
	
	public Car save(Car car) throws CarException {
		// TODO Auto-generated method stub
		Dbutil.listcar.put(car.getCarno(),car);
		return car;
		
	}
	  /*
    this method is is finding 
    the booking detail of the car into the Map collection
  */

	public Car findCarByNo(String carno) throws CarException {
		// TODO Auto-generated method stub
		Car obj=Dbutil.listcar.get(carno);
		return obj;
		
		  
	}
	
	  /*
    this method is is getting all car
     booking detail.
  */

	public List<Car> geCars() throws CarException {
		// TODO Auto-generated method stub
		if(Dbutil.listcar.isEmpty())
		{
			 return null;
		}
		else
		{
	     Collection<Car> values = Dbutil.listcar.values(); 
	     ArrayList<Car> listOfValues = new ArrayList<Car>(values);
	      return listOfValues;
	  }
	}
	
	  /*
    this method is is deleting
    the booking detail of the car
  */

	public boolean delete(String carno) throws CarException {
		// TODO Auto-generated method stub
		Car car=Dbutil.listcar.get(carno);
		if(car==null)
		{
			 return false;
		}
		else {
			Car obj=Dbutil.listcar.remove(carno);
		
		return true;
		}
		
		
		
	}
	 
	   
	 
	}
