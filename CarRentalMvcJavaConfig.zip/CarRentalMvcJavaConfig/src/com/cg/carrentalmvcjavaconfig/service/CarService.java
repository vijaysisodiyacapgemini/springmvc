package com.cg.carrentalmvcjavaconfig.service;

import java.util.List;

import com.cg.carrentalmvcjavaconfig.dto.Car;
import com.cg.carrentalmvcjavaconfig.exception.CarException;



public interface CarService {
	  public List<Car> viewAvailableCars() throws CarException;
	    public Car bookCar(Car car) throws CarException; 
	    public Car showBookingDetail(String carno) throws CarException;
	    public boolean cancelBooking(String carno) throws CarException;

}
