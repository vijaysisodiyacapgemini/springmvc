package com.cg.carrentalmvcjavaconfig.dto;

import java.math.BigInteger;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Entity
@Table(name="car")
public class Car {
	@Id
	private String carno;
	private String carCategory;
	private float rateHour;
    @OneToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="booking_id")
	private BookingDetail bookingdetail;
	public String getCarno() {
		return carno;
	}
	public void setCarno(String carno) {
		this.carno = carno;
	}
	public String getCarCategory() {
		return carCategory;
	}
	public void setCarCategory(String carCategory) {
		this.carCategory = carCategory;
	}
	public float getRateHour() {
		return rateHour;
	}
	public void setRateHour(float rateHour) {
		this.rateHour = rateHour;
	}
	
	public BookingDetail getBookingdetail() {
		return bookingdetail;
	}
	public void setBookingdetail(BookingDetail bookingdetail) {
		this.bookingdetail = bookingdetail;
	}
	@Override
	public String toString() {
		return "CAR NO:" + carno + "  " + carCategory + "  Rate/Hour:"  + rateHour + " "
				+ bookingdetail;
	}
	 
}
