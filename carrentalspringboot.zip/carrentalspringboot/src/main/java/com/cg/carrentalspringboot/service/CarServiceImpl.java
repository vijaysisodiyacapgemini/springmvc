package com.cg.carrentalspringboot.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.carrentalspringboot.dao.CarDao;
import com.cg.carrentalspringboot.dto.Car;
import com.cg.carrentalspringboot.exception.CarException;

@Service
public class CarServiceImpl implements CarService{
	
	@Autowired
	CarDao cardao;

	@Override
	public List<Car> viewAvailableCars() throws CarException {
		return null;
		
	/*	// TODO Auto-generated method stub
		List<Car> car= 
		
		 if(cardao.findAll().isEmpty())
		   {
			   throw new CarException(" No One has booked the car");
		   }
		   else
		   {
			   return 
		   }
		
	*/	
	}
	 /* 
	  *above method is getting all the Booked cars 
	  */

	@Override
	public Car bookCar(Car car) throws CarException {
		// TODO Auto-generated method stub
		 Car carobj=cardao.save(car);    
			if(car==null)
			{
				throw new CarException("you are not booking the car");
			}
			else
			{
				return carobj;
			}
			
		
		
	}
	/* 
	  *above method is Booking the  cars 
	  */

	@Override
	public Car showBookingDetail(String carno) throws CarException {
		
		
		
		
		// TODO Auto-generated method stub
		
		 Car obj= cardao.findBycarno(carno);
		   if(obj==null)
				throw new CarException("please Enter your Correct Booking  car Number");
			else
			{
	
	         return obj;
			}
		
	
	}
	/* 
	  *above method is getting the booking detail of  the cars 
	  */

	@Override
	public boolean cancelBooking(String carno) throws CarException {
		
		     
		// TODO Auto-generated method stub
		  Car obj=cardao.findBycarno(carno);
		  if(obj!=null)
		  {
			   cardao.delete(obj);
			  return true;
		  }
		  else
		  {
			  throw new CarException("please enter valid car Number");
		   }
	   }
	/* 
	 * this method is deleting the booking car detail
	 */
  
}

