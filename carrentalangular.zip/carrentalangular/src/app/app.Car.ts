import { BookingDetail } from "./app.BookingDetail";

export class Car
{
    carno:string;
    carCategory:string;
    rateHour:number;
    bookingdetail:BookingDetail;
    
    
}