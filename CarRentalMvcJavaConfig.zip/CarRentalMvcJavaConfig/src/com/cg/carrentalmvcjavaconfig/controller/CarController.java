package com.cg.carrentalmvcjavaconfig.controller;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.carrentalmvcjavaconfig.dto.BookingDetail;
import com.cg.carrentalmvcjavaconfig.dto.Car;
import com.cg.carrentalmvcjavaconfig.dto.Driver;
import com.cg.carrentalmvcjavaconfig.exception.CarException;
import com.cg.carrentalmvcjavaconfig.service.CarService;


/*
 * author: vijay sisodiya
 * date:22-05-2019
 */

@Controller
public class CarController {
	
	Car carobj;
	BookingDetail bookingobj;
	public CarController()
	{
		
	}
	
	@Autowired
	CarService service;
	List<Driver> mylist=new ArrayList<Driver>();
	
	@GetMapping("login")
    public String loginPage()
	{
		return "listpage";
	}
	
	
	
	
	@GetMapping("book")
	public ModelAndView getAddCar(@ModelAttribute("carprod") Car car)
	
	{
		 return new ModelAndView("carbook");
		 
	}
	@PostMapping("bookingdetail")
	public ModelAndView getAddBooking(@ModelAttribute("carprod") Car car)
	{
		 
			try {
				service.showBookingDetail(car.getCarno());
				return new ModelAndView("error");
			} 
			catch (CarException e) {
				// TODO Auto-generated catch block
				this.carobj=car;
				
				  return new ModelAndView("bookingdetail");
				
			}
			
	}
			
	@PostMapping("driver")
	public ModelAndView getAdddriver(@RequestParam("id") int id,
			@RequestParam("pickupPoint") String ppoint,
			@RequestParam("dropPoint") String  dpoint,
			@RequestParam("pickupDate") String pdate,
			
			@RequestParam("dropDate") String ddate,
			@RequestParam("ptime") String string1,
			@RequestParam("dtime") String string2
			)
	{
		
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/mm/yyyy hh:mm");
		Date pickupDate = null;
		Date dropDate=null;
		try {
			pickupDate = dateFormat.parse(pdate+" "+string1);
		    dropDate=dateFormat.parse(ddate+" "+string2);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			return new ModelAndView("error4");
		}
		 long diff = dropDate.getTime() - pickupDate.getTime();  // calculating the amount of booking 
		  long diffMinutes = diff / (60 * 1000) % 60;
		  long diffHours = diff / (60 * 60 * 1000);
	     BigDecimal totalamount=BigDecimal.valueOf((carobj.getRateHour()*diffHours)+(carobj.getRateHour()/60*diffMinutes));
	     BookingDetail bookingdetail=new BookingDetail();
	    bookingdetail.setId(id);
	    bookingdetail.setPickupPoint(ppoint);
	    bookingdetail.setDropPoint(dpoint);
		bookingdetail.setTotalamount(totalamount);		
		
		bookingdetail.setPickupDate(pickupDate);
		bookingdetail.setDropDate(dropDate);
	    this.bookingobj=bookingdetail;
	
	   return new ModelAndView("driver");
	}
	/*
	 * above method is taking the Booking Detail from the user
	 * 
	 */
	
	@PostMapping("finalsubmit")
	public ModelAndView getAdddata(@RequestParam("name") String name,
			@RequestParam("mobNumber") Long mobnumber,
			@RequestParam("licence") String licence)
	
	{
		
		Driver driver=new Driver();
		driver.setName(name);
		driver.setMobNumber(mobnumber);
		driver.setLicenceNumber(licence);
		mylist.add(driver);
		return new ModelAndView("temporary");
	}
	/*
	 * above method taking the driver detail from the user
	 * 
	 */
	
	  @GetMapping("finalsubmit1")
		public ModelAndView finaldata()
		{
		bookingobj.setDrivers(mylist);
		carobj.setBookingdetail(bookingobj);
		try {
			service.bookCar(carobj);
		} catch (CarException e) {
			// TODO Auto-generated catch block
			System.out.println();
		}
	   return new ModelAndView("success");
	}		
		/*
		 * 
		 * above method is submitting all the data
		 * 	
		 */
	@GetMapping("show")
    public ModelAndView getbooking(@ModelAttribute("carprod") Car car)
	{
		
		return new ModelAndView("showbooking");
	}
	
	/*
	 * 
	 * method is returning the showbooking page
	 */
	
	@PostMapping("findbooking")
    public ModelAndView findbooking(@ModelAttribute("carprod") Car car)
    
	{
		try {
		Car obj= service.showBookingDetail(car.getCarno());
		
	
	
		return new ModelAndView("showbooking","result", obj);
		
		}
		catch(CarException e)
		{
			return new ModelAndView("error1");
		}
	
	}	
	/*
	 * above method is finding the booking detail of the car
	 * 
	 */
	@GetMapping("cancel")
    public ModelAndView getcancel(@ModelAttribute("carprod") Car car)
	{
		
		return new ModelAndView("cancelbooking");
	}
	
	@PostMapping("findcancel")
    public ModelAndView addcancel(@ModelAttribute("carprod") Car car)
    
	{
		try {
		boolean obj= service.cancelBooking(car.getCarno()); 
		return new ModelAndView("listpage");
		}
		catch(CarException e)
		{
		return new ModelAndView("error2");
		}
		
	}	
	
	/*
	 * this method is canceling the detail of the car
	 * and handling the exception also
	 * 
	 * 
	 */
	
	@GetMapping("showall")
    public ModelAndView addshowall(@ModelAttribute("carprod") Car car)
    
	{
		try {
		List<Car> mylist= service.viewAvailableCars(); 
		System.out.println(mylist);
		return new ModelAndView("showall","result1", mylist);
		}
		catch(CarException e)
		{
			return new ModelAndView("error1");
		}
		
	}	
	@GetMapping("driveragain")
    public ModelAndView driveragain()
	{
		
		return new ModelAndView("driver");
	}		
		/*
		 * this is asking for one to many operation
		 * 	
		 */
	
	

	
	
}

