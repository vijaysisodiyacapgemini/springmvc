package com.cg.onlinecarjdbc.dto;

import java.math.BigInteger;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.OptimisticLockType;
import org.hibernate.annotations.OptimisticLocking;
@Entity
@Table(name="car")
public class Car {
	@Id
	
	private String carno;
   
	private String carCategory;
   
	private float rateHour;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="booking_id")
	private BookingDetail bookingdetail;
	public Car()
	{
		
	}
	public String getCarno() {
		return carno;
	}
	public void setCarno(String carno) {
		this.carno = carno;
	}
	public String getCarCategory() {
		return carCategory;
	}
	public void setCarCategory(String carCategory) {
		this.carCategory = carCategory;
	}
	public float getRateHour() {
		return rateHour;
	}
	public void setRateHour(float rateHour) {
		this.rateHour = rateHour;
	}
	public Car(String carno, String carCategory, float rateHour, BookingDetail bookingdetail) {
		super();
		this.carno = carno;
		this.carCategory = carCategory;
		this.rateHour = rateHour;
		this.bookingdetail = bookingdetail;
	}
	public BookingDetail getBookingdetail() {
		return bookingdetail;
	}
	public void setBookingdetail(BookingDetail bookingdetail) {
		this.bookingdetail = bookingdetail;
	}
	@Override
	public String toString() {
		return "CAR NO:" + carno + "  " + carCategory + "  Rate/Hour:"  + rateHour + " "
				+ bookingdetail;
	}
	 
}
