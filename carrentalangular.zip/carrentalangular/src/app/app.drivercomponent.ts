import { Component,OnInit } from '@angular/core';


import { CarService } from './app.carservice';
import { Driver } from './app.driver';

@Component({
    selector: 'driver-app',
    templateUrl: 'driver.html'
})



export class Drivercomponent  {

//  book=new FormGroup({
// id : new FormControl(''),
// totalAmount : new FormControl(''),
// custId : new FormControl('')

// });  

model:any={};

constructor(private carservice:  CarService ){
}
driverdata=false;

drivers:Driver[]=[];

driver={ mobnumber:0,   licence:'', name:'' };


 adddriver()
 {
    console.log(this.model);
    this.driverdata=true;
 }

adddrivers()
{
this.drivers.push(this.driver);
console.log(this.drivers);
   this.driver={
    mobnumber:0,   licence:'', name:''
   }
}

 addBooking()
{ this.drivers.push(this.driver);
   this.model['drivers']=this.drivers;
    console.log(this.model);
    this.carservice.addCarOne(this.model);//subscribe((data=>console.log(data)));
 }
}
