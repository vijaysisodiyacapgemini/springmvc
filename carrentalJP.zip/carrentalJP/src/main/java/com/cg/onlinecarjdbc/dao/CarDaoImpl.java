package com.cg.onlinecarjdbc.dao;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.cg.onlinecarjdbc.dto.*;
import com.cg.onlinecarjdbc.dto.Driver;
import com.cg.onlinecarjdbc.query.CarQuery;

import java.util.*;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import com.cg.onlinecarrental.exception.CarException;
import com.cg.onlinecarrental.util.Dbutil;
 
 
public class CarDaoImpl implements CarDao {
	 
	   
	 
	   EntityManager em=null;
	   public CarDaoImpl()
	   {
		  em=Dbutil.getConnection();
	   }
	
	
	
	public Car save(Car car) throws CarException {
		em.getTransaction().begin();
	    em.persist(car);
        em.getTransaction().commit();
        
         
      
		
		return car;
		
	
	 
	 
		// TODO Auto-generated constructor stub

   
  

}

	public Car findCarByNo(String carno) throws CarException {
		// TODO Auto-generated method stub
		
		return null;
	}

	public List<Car> geCars() throws CarException {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean delete(String carno) throws CarException {
		// TODO Auto-generated method stub
		return false;
	}
}