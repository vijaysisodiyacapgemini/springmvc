package com.cg.carrentalmvcjavaconfig.dao;
import java.util.List;

import com.cg.carrentalmvcjavaconfig.dto.Car;
import com.cg.carrentalmvcjavaconfig.exception.CarException;



public interface CarDao {
	public Car save(Car car);
	public Car findCarByNo(String carno);
	public List<Car> geCars();
	public boolean delete(String carno);
	 

}
