
import { Component, OnInit, Input } from "@angular/core";
import { Router } from "@angular/router";

import { CarService } from "./app.carservice";
import { Car } from "./app.Car";

@Component({
    selector:'booking-app',
    templateUrl:'bookingdetail.html'
})

export class BookingComponent implements OnInit
{

   carobj:Car[];
 
   constructor(private carservice:CarService){ 
   
    
   }
  
   ngOnInit()
   {
    
      
      
      
     
      
   }
   
   showall()
   {
      
      this.carservice.showall().subscribe((data:Car[])=>this.carobj=data);
    
   

    
   }
}