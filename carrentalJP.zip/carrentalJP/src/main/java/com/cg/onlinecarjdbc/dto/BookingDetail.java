package com.cg.onlinecarjdbc.dto;
import java.util.*;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
public class BookingDetail {
	@Id
    private int id;
	private String pickupPoint;
	private String dropPoint;
	@Temporal(TemporalType.TIMESTAMP)
	private Date pickupDate;
	@Temporal(TemporalType.TIMESTAMP)
	private Date dropDate;
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="booking_id")
	private List<Driver> drivers;
	public  int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}


	public String getPickupPoint() {
		return pickupPoint;
	}

	public void setPickupPoint(String pickupPoint) {
		this.pickupPoint = pickupPoint;
	}

	public String getDropPoint() {
		return dropPoint;
	}

	public void setDropPoint(String dropPoint) {
		this.dropPoint = dropPoint;
	}

	public Date getPickupDate() {
		return pickupDate;
	}

	public void setPickupDate(Date pickupDate) {
		this.pickupDate = pickupDate;
	}

	public Date getDropDate() {
		return dropDate;
	}

	public void setDropDate(Date dropDate) {
		this.dropDate = dropDate;
	}

	public List<Driver> getDrivers() {
		return drivers;
	}

	public void setDrivers(List<Driver> drivers) {
		this.drivers = drivers;
	}
	@Override
	public String toString() {
		return "\n PickupPoint: " + pickupPoint + " DropPoint:" + dropPoint + ",\n PickupDate : " + pickupDate
				+ " DropDate:" + dropDate +  "\n "
				+ drivers;
	}

}
