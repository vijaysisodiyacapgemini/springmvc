import {Injectable, Input} from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';

import { throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';


@Injectable({
    providedIn:'root'
})
export class CarService
{
 

      constructor(private http:HttpClient){}
    
      showBookingDetails(carnumber:string){
         console.log(carnumber);
         let params=new HttpParams().set("carno",carnumber);
       return this.http.post("http://localhost:8088/car/showbookingdetail",params).pipe(
         retry(1),
         catchError(this.handleError)
       );
       
   


      }
      

      showall()
      {
         return  this.http.get("http://localhost:8088/car/showall");
           
      }
     
      cancel(carno:string)
      {
         let params=new HttpParams().set("carno",carno);
         return this.http.post("http://localhost:8088/car/cancel",params).pipe(
            retry(1),
            catchError(this.handleError)
          );
      }
    
      handleError(error) {
         let errorMessage = '';
          if(error.status=404)
          {
         window.alert(error.error);
      }
         return throwError(errorMessage);
       }
      addCarOne(carobj:any):any
{
let i:number=0;    
var input= new FormData();
input.append("carno", carobj.carno);
         input.append("carCategory", carobj.carCategory);
         input.append("rateHour", carobj.rateHour);
         input.append("bookingdetail.pickupPoint", carobj.pickupPoint);
         input.append("bookingdetail.dropPoint", carobj.dropPoint);
         input.append("bookingdetail.id", carobj.id);
         input.append("bookingdetail.pickupDate", carobj.pickupDate);
         input.append("bookingdetail.dropDate", carobj.dropDate);


while(i<carobj.drivers.length) {
console.log(i);

input.append("bookingdetail.drivers["+i+"].mobNumber", carobj.drivers[i].mobnumber);
input.append("bookingdetail.drivers["+i+"].name", carobj.drivers[i].name);
input.append("bookingdetail.drivers["+i+"].LicenceNumber", carobj.drivers[i].licence);
i++;
}  
 
return this.http.post("http://localhost:8088/car/addall",input);
 
}
   }