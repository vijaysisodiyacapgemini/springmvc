import { CarService } from "./app.carservice";
import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { Car } from "./app.Car";

@Component({
    selector:'search-app',
    templateUrl:'showBookingDetail.html'
})
export class showBookingDetail implements OnInit
{

   constructor(private router:Router,public carservice:CarService){ }
   model:string;
   result:any;

   ngOnInit()
   {
     
   }
  
   onSearch()
   {   //console.log(this.result);
    this.carservice.showBookingDetails(this.model).subscribe((data:Car) =>this.result=data); 

   }
}